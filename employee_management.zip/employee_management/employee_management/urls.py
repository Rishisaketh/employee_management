from django.urls import path
from employees.views import add_employee, edit_employee, delete_employee, employee_list

urlpatterns = [
    path('employee/add/', add_employee, name='add_employee'),
    path('employee/edit/<int:employee_id>/', edit_employee, name='edit_employee'),
    path('employee/delete/<int:employee_id>/', delete_employee, name='delete_employee'),
    path('', employee_list, name='employee_list'),
]

